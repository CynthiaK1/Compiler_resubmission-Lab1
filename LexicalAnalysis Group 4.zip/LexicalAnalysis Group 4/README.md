# LexicalAnalysis
This repo contains a file that converts a sentence into its components.
